---
name: quiz-generator
description: Produce structured Pinyin-first Mandarin questions with unique answer keys and validated distractors.
---
# Skill — Quiz Generator

## When to use
Generate, import, review, revise, deduplicate, or publish question banks.

## Inputs
`topic`, `level`, `question_type`, `count`, `pinyin_only`, `approved_vocabulary`, `language_vi`, `learning_objective`.

## Generation workflow
1. Prefer approved vocabulary; request or explicitly label assumptions if absent.
2. Produce structured items against `shared/question.schema.json`.
3. Use Pinyin Expert to validate spelling, tone marks, meanings, and sandhi notes.
4. Ensure exactly one unambiguous correct option unless a multi-answer question is explicitly requested.
5. Ensure distractors are plausible but demonstrably incorrect, not duplicate strings or trivial typography variants.
6. Normalize Unicode NFC, trim whitespace, detect duplicate IDs and semantic duplicates.
7. Run schema and deterministic answer checks. Set `review_status=draft` until a teacher reviews and publishes it.
8. Log content version and revision reason; never silently mutate a published item.

## Question design rules
- One learning objective per item.
- Vietnamese instructions must be clear and level-appropriate.
- Never expose answer IDs to learners before submission.
- No Hanzi in learner-visible fields when `pinyin_only=true`.
- Use separate `teacher_notes` for Hanzi, lexical citations, or linguistic rationale.
- For audio items, require a real asset reference and verify the asset exists; otherwise mark item incomplete.

## Output
JSON array of schema-compliant questions plus a validation report with passed/failed checks and items requiring teacher review.

## Acceptance tests
- Exactly four unique options for `single_choice` in the starter schema.
- `correct_option_id` matches exactly one option.
- All learner-facing fields obey Pinyin-only mode.
- All new questions are `draft` and cannot be published without review.
- Reject duplicate IDs and invalid schema.
