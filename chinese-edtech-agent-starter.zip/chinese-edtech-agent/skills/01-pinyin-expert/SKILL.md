---
name: pinyin-expert
description: Validate Hanyu Pinyin, syllables, tone notation, and Mandarin pronunciation teaching for Vietnamese learners.
---
# Skill — Pinyin Expert

## When to use
Any Pinyin content, syllable list, pronunciation explanation, tone task, romanization, or language item review.

## Inputs
`pinyin`, optional `hanzi` (teacher metadata only), `meaning_vi`, `level`, `pinyin_only`, `context`, `task_type`.

## Procedure
1. Normalize text to Unicode NFC; preserve case only where appropriate (e.g., proper nouns).
2. Validate standard Hanyu Pinyin orthography and syllable inventory, including `ü`, `j/q/x + u` spelling, `y/w` conventions, apostrophes for syllable boundaries, and tone mark placement.
3. Distinguish lexical citation tones from tone sandhi in connected speech (third-tone sequences, `不`, `一`). Never silently replace dictionary transcription with contextual pronunciation.
4. Check tone-mark placement (a/o/e precedence, `iu`/`ui` mark on final vowel), neutral tone, and valid syllable combinations. `v` may be accepted only as an input alias for `ü`, not as display orthography.
5. For learner-facing `pinyin_only=true`, remove Hanzi from all rendered learner fields; teacher metadata may retain Hanzi.
6. Verify that Vietnamese explanations describe articulation without claiming exact one-to-one sound equivalence.
7. Mark uncertain, dialect-dependent, or context-sensitive cases `needs_teacher_review`.

## Output contract
Return `normalized_pinyin`, `meaning_vi`, `level`, `citation_tone`, `spoken_tone_note`, `issues[]`, `validation_status` (`valid|invalid|needs_teacher_review`), and `explanation_vi`.

## Examples
- `nǐ hǎo`: dictionary transcription valid; contextual third-tone sandhi may affect the first syllable in connected speech.
- `lǜ`: valid orthography; display `ü` with tone mark, not `lv`.
- `shuǐ`: valid; tone mark over `i` in `ui`.
- `mǎ`: valid tone 3; do not confuse with `má`.

## Failure modes / safeguards
- Do not validate only with a loose regex; check a curated syllable inventory and known exceptions.
- Do not infer tone from Vietnamese meaning alone.
- Do not fabricate IPA or audio judgments; flag for review if uncertain.
- Do not assume every multi-syllable item has one fixed contextual pronunciation.

## Acceptance tests
- Correctly reject misplaced tone marks and invalid syllable spellings.
- Preserve `ü` and NFC normalization.
- Explain dictionary vs spoken sandhi distinctly.
- No Hanzi appears in learner output when `pinyin_only=true`.
