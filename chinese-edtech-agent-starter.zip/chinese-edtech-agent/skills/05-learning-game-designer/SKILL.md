---
name: learning-game-designer
description: Design accessible, pedagogically sound Pinyin-first Mandarin learning games and scoring.
---
# Skill — Learning Game Designer

## When to use
Game ideas, rounds, streaks, timers, scoring, levels, hints, retries, or learning progress.

## Inputs
`learning_objective`, `age_group`, `level`, `session_minutes`, `input_method`, `pinyin_only`, `question_source`, `accessibility_needs`.

## Procedure
1. State a measurable learning objective and identify the Pinyin Expert / Quiz Generator checks required.
2. Choose mechanics that assess the objective, not just reaction speed. Offer untimed mode by default.
3. Specify start, tutorial, round, feedback, retry, finish, and resume states.
4. Define deterministic scoring independent of AI text generation; cap bonuses and avoid negative scores.
5. Provide feedback for each answer: correctness, why, and a chance to retry.
6. Define adaptive difficulty using observable performance; avoid overclaiming proficiency.
7. Make touch, keyboard, screen-reader, low-bandwidth, and reduced-motion behavior explicit.
8. Specify data events, persistence boundaries, and teacher-facing reports without collecting unnecessary personal data.

## Recommended initial game
**Pinyin Tone Quest**: hear or read a Pinyin prompt, choose among four tone-distinct options, get an explanation, retry errors, and see progress by tone. Audio is optional and must not be fabricated or assumed to exist.

## Output template
- Objective and audience
- Core loop and state diagram
- Example rounds (teacher-reviewed)
- Scoring formula and anti-duplicate logic
- Accessibility / mobile UX
- Data events and persistence
- Acceptance tests

## Safety / quality gates
- No leaderboard with public child identifiers by default.
- No endless loops, manipulative streak pressure, or penalty for accessibility accommodations.
- Wrong answers must not teach false Pinyin forms.
- If the task needs audio, define asset licensing, loading, and fallback behavior.
