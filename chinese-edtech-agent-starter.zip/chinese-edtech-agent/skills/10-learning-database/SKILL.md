---
name: learning-database
description: Design secure server-persisted question banks, teacher administration, and learner progress.
---
# Skill — Learning Database

## When to use
Data schema, saving questions, authentication, content publishing, progress, analytics, imports, backups, or migrations.

## Inputs
`database_provider`, `auth_provider`, `roles`, `expected_scale`, `offline_mode`, `retention_policy`, `hosting`.

## Core entities
- `users`: minimal profile and role, never passwords in application tables.
- `question_banks`: owner, topic, level, version, visibility.
- `questions`: immutable ID, bank ID, content, schema version, draft/review/published status, reviewer, timestamps.
- `attempts`: user ID, question version, selected option, correctness, duration if needed, timestamp.
- `learning_progress`: per-user topic summaries derived from attempts, never the sole record of truth.

## Procedure
1. Confirm backend/database selection and permissions; do not claim a service is connected without verification.
2. Define authorization matrix: teacher creates/reviews/publishes assigned banks; learner reads only published content and own attempts; admin manages access.
3. Enforce roles and ownership on server/API and database rules, not merely UI.
4. Validate data server-side against versioned schema; reject malformed or unauthorized writes.
5. Use idempotent writes, timestamps, pagination, and indexes for common queries.
6. Support export/import, backups, versioning, and reversible migrations. Require approval for destructive changes.
7. For cross-device persistence, authenticate users and verify reading their saved progress from another browser.
8. Define data minimization, retention, deletion/export, and consent requirements appropriate to deployment and student age.

## Firebase/Firestore guidance
Use Firebase Authentication and Firestore security rules, deny by default, and test rules in an emulator. Avoid trusting a client-supplied `role`; use securely assigned roles/claims or server-managed membership. Never put service account keys in frontend.

## PostgreSQL guidance
Use migrations, parameterized queries, least-privilege credentials, and row-level security or equivalent server-side authorization. Test tenant isolation.

## Local storage policy
`localStorage` may cache non-sensitive UI preferences or drafts; it is not the authoritative store for shared questions, published banks, or progress.

## Acceptance tests
- Unauthorized learner cannot create or publish questions.
- Learner cannot read another learner's attempts.
- Published content remains accessible after clearing browser storage.
- Cross-device progress survives a new session.
- Backup/restore and migration rollback documented.
