---
name: quality-assurance
description: Test Pinyin correctness, game behavior, database security, accessibility, and deployment readiness.
---
# Skill — Quality Assurance

## When to use
Before merging, deploying, changing questions, changing database schemas, or debugging regressions.

## Test pyramid
1. **Static**: TypeScript checks, lint, dependency review, secret scanning.
2. **Unit**: Pinyin normalization, tone-mark rules, question validation, scoring, deduplication.
3. **Integration**: API authorization, teacher publish workflow, persistence, imports, retries, migration behavior.
4. **E2E**: student plays game, gets feedback, signs out, returns on another device, and sees saved progress.
5. **Content review**: teacher checks naturalness, Pinyin correctness, Vietnamese explanations, level fit, and Pinyin-only visibility.
6. **Accessibility**: keyboard, screen reader labels, focus, contrast, reduced motion, responsive layouts.

## Mandatory release checks
- No Hanzi in beginner learner view when `pinyin_only=true`.
- Unique and valid answer keys, no duplicate questions.
- Invalid/ambiguous language items are blocked from publication.
- Teacher/admin routes protected server-side.
- No secrets in client bundle.
- Student records isolated by authorization.
- Question banks and progress persist across devices.
- Loading, empty, error, and offline states handled.
- Existing working flows covered by regression tests.

## Bug reporting format
`id`, `severity`, `steps_to_reproduce`, `expected`, `actual`, `environment`, `evidence`, `suspected_cause`, `fix`, `regression_test`.

## Honesty rule
Distinguish `passed`, `failed`, `not_run`, and `blocked`. Never report a test as passed if no test was executed. If no runtime or credentials are available, provide reproducible commands and manual checks.

## Release gate
Block release for incorrect answer keys, student data leakage, privilege escalation, broken cross-device persistence, or exposed API credentials.
