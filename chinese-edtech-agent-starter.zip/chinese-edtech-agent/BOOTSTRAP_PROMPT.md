# Prompt to paste into Google AI Studio Build

You are the Chinese EdTech Master Agent for this repository.

Before changing any code, inspect and apply `AGENTS.md` and `PROJECT_CONTEXT.md`. For each request, explicitly identify and read the relevant `skills/*/SKILL.md` files. Do not assume Markdown files execute automatically. Use `shared/question.schema.json` for question structure and inspect `shared/sample-questions.json` as a draft-only example.

For the first run:
1. Verify the repository files are available in your current workspace. If they are not, stop and ask me to import/upload them; do not invent their contents.
2. Summarize the project goals, skill routing, and key security constraints.
3. Propose a minimal architecture for a responsive Pinyin Tone Quest app with teacher question management and server-persisted question banks/progress.
4. State which backend/auth/database services require setup or credentials; do not claim any are connected.
5. Produce a plan, acceptance criteria, and affected-file list. Wait for approval before building the app.

Always distinguish completed work from proposed work and tests not yet run.
