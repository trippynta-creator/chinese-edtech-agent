# Project Context — Chinese EdTech Vietnam

## Vision
A family of modern Mandarin teaching applications for Vietnamese-speaking teachers and learners, with an initial focus on practical spoken Mandarin and Pinyin before Chinese characters.

## Users
- **Teacher/admin**: authors, reviews, imports, publishes, and revises question banks; assigns lessons; reviews aggregated progress.
- **Learner**: practices listening, recognition, Pinyin, tones, vocabulary, and conversational responses with clear, supportive feedback.

## Teaching principles
1. Communication-first, with meaningful real-life situations and contemporary, natural Standard Mandarin.
2. Pinyin-first for beginner courses. `pinyin_only=true` suppresses Hanzi in learner-facing UI, prompts, options, hints, and explanations.
3. Teach tone perception and production deliberately; avoid treating accent differences as moral or intellectual shortcomings.
4. Scaffold from recognition to recall to production; gradually increase difficulty.
5. Feedback explains the error and gives a concrete retry opportunity; avoid punitive gamification.
6. Do not claim to measure pronunciation objectively without appropriate audio evidence and a calibrated evaluation method.
7. Teacher review is required before AI-generated content becomes published content.

## Initial scope
- Pinyin initial/final recognition, syllable assembly, tone identification, Pinyin–Vietnamese meaning matching, and simple spoken dialogues.
- Mobile-first browser apps that also work on desktop.
- Vietnamese interface, Standard Mandarin learning content.
- Separate teacher/admin and student modes.

## Content levels (internal; not official HSK equivalence)
- L0: initials, finals, syllables, tone-mark awareness.
- L1: tone contrasts, basic words, greetings, numbers, everyday vocabulary.
- L2: short phrases and conversational patterns.
- L3: short dialogues and situational practice.

## Data and privacy
- Store reusable question banks and learning records server-side with backups and export capability.
- Minimize personally identifying learner data. Set retention and deletion policies before production.
- Teachers control publishing and corrections. Track content version, reviewer, and publication status.
- Never expose student records to other students.

## UX language and defaults
- UI language: Vietnamese (`vi-VN`).
- Learning language: Standard Mandarin, Hanyu Pinyin.
- Default learner mode: `pinyin_only=true`.
- Default visual style: friendly, readable, uncluttered; large tap targets, keyboard navigation, accessible contrast.
- Feedback: short, encouraging, and specific; no excessive animations or dark patterns.

## Success metrics
- Accuracy by tone/initial/final, completion rate, retry improvement, content error rate, question validation pass rate, and successful cross-device persistence.
- Avoid treating raw game points alone as learning outcomes.

## Technical baseline
- React + TypeScript frontend.
- Server-side API for authentication, validation, AI requests, and persistence.
- Choose Firebase/Firestore or PostgreSQL according to the app's query and deployment needs; do not assume a provider is configured.
- Use versioned content schemas, automated tests, and Git-based change review.

## Out of scope unless requested
- Full Hanzi-first literacy curriculum, high-stakes proficiency certification, unvalidated automated speaking grades, paid billing, or broad social features.
