# Chinese EdTech Agent Skills — Starter Kit

Reusable Markdown instructions for building modern Mandarin/Pinyin-first learning apps for Vietnamese learners using Google AI Studio.

## Contents
- `AGENTS.md`: master operating contract and skill routing.
- `PROJECT_CONTEXT.md`: educational product requirements.
- `skills/*/SKILL.md`: five specialist skills.
- `shared/question.schema.json`: starter single-choice JSON Schema.
- `shared/sample-questions.json`: illustrative draft item, not teacher-approved content.
- `BOOTSTRAP_PROMPT.md`: initial prompt for Google AI Studio Build.

## Setup
1. Unzip this folder and create a private GitHub repository. Commit all files.
2. Open Google AI Studio Build and import/sync the repository if the feature is available in your workspace; otherwise copy/upload the files into the project's workspace. Confirm the files are visible to the agent.
3. Paste the text from `BOOTSTRAP_PROMPT.md` into the Build prompt.
4. Ask the agent to read `AGENTS.md`, `PROJECT_CONTEXT.md`, and relevant skill files, and request a plan before coding.
5. Configure a backend, authentication, and server-side database before enabling shared question editing or progress syncing. Never paste production secrets into prompts or frontend code.
6. Add app-specific specifications under `apps/<app-name>/`.
7. Review generated questions as a teacher before publishing them.

## Scope notes
These files are reusable instructions, not executable agents or an automatically installed skill runtime. The JSON Schema checks structure, not linguistic truth; implement extra validation (unique option IDs/text, answer membership, Unicode NFC, no Hanzi in learner fields) in application code and tests. The schema `$id` is a placeholder and should be replaced with a real project-controlled URI if published. The starter sample remains a draft.

## Suggested first app
Pinyin Tone Quest: responsive, untimed four-choice tone identification; teacher review/publish; learner retries; authenticated cross-device progress.
